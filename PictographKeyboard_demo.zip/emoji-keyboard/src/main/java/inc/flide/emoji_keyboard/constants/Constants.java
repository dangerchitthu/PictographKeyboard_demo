package inc.flide.emoji_keyboard.constants;

public interface Constants {
    String EMOJI_KEYBOARD_ID = "inc.flide.emojiKeyboard/inc.flide.ime.EmojiKeyboardService";
    int DELAY_MILLIS_LONG_PRESS_INITIATION = 500;
    int DELAY_MILLIS_LONG_PRESS_CONTINUATION = 50;
}
