package inc.flide.emoji_keyboard.constants;

public enum EmojiCategory {
    people, nature, activity, food, travel, objects, symbols, flags, modifier, regional
}
